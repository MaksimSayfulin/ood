#pragma once
#include <memory>
#include <string>
#include <vector>

#include "../Graphics/Canvas/ICanvas/ICanvas.h"
#include "../Shape/IShape/IShape.h"
#include "../Shape/ShapeGeometry/IShapeGeometry.h"
#include "../Observer/Observer.h"

namespace shapes {
    class Picture : public CObservable<const Picture*>, public IObserver<const IShape*> {
    public:
        explicit Picture(gfx::ICanvas &canvas);
        Picture(const Picture& other);

        ~Picture();

        void AddShape(const std::string& id, const gfx::Color& color, std::unique_ptr<IShapeGeometry> geometry);
        void AddShape(const IShape &shape);

        void MoveShape(const std::string& id, double dx, double dy);
        void MovePicture(double dx, double dy);
        void DeleteShape(const std::string& id);
        void List() const;

        void ChangeColor(const std::string &id, const gfx::Color &color);
        void ChangeShape(const std::string &id, std::unique_ptr<IShapeGeometry> geometry);

        void DrawShape(const std::string &id);
        void DrawPicture() const;

        void Update(const IShape* const& data) override;
        [[nodiscard]] size_t GetShapesCount() const;
        [[nodiscard]] IShape& GetShape(const std::string& id);

    protected:
        [[nodiscard]] const Picture* GetChangedData() const override;

    private:
        gfx::ICanvas& m_canvas;
        std::vector<IShape> m_shapes;

        IShape* FindShape(const std::string& id);
    };
}