#pragma once

#include <ostream>
#include "../../Picture/Picture.h"
#include "../../Observer/Observer.h"

namespace shapes {

    class ConsolePictureObserver : public IObserver<const Picture*> {
    public:
        explicit ConsolePictureObserver(std::ostream& output)
            : m_output(output) {}

        void Update(const Picture* const& picture) override {
            if (picture) {
                m_output << "Picture changed. Shapes: " << picture->GetShapesCount() << "\n";
            }
        }

    private:
        std::ostream& m_output;
    };
}