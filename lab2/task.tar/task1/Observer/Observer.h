#pragma once

#include <set>

template <typename T>
class IObserver
{
public:
    virtual void Update(T const& data) = 0;
    virtual ~IObserver() = default;
};

template <typename T>
class IObservable
{
public:
    virtual ~IObservable() = default;
    virtual void RegisterObserver(IObserver<T> & observer) = 0;
    virtual void NotifyObservers() = 0;
    virtual void RemoveObserver(IObserver<T> & observer) = 0;
};

template <class T>
class CObservable : public IObservable<T>
{
public:
    typedef IObserver<T> ObserverType;

    CObservable() = default;
    CObservable(const CObservable&) : m_observers() {}

    void RegisterObserver(ObserverType & observer) override
    {
        m_observers.insert(&observer);
    }

    void NotifyObservers() override
    {
        T data = GetChangedData();
        for (auto & observer : m_observers)
        {
            observer->Update(data);
        }
    }

    void RemoveObserver(ObserverType& observer) override
    {
        m_observers.erase(&observer);
    }

    bool IsObserverRegistered(IObserver<T>& observer) {
         return std::find(m_observers.begin(), m_observers.end(), observer);
    }

protected:
    virtual T GetChangedData()const = 0;

private:
    std::set<ObserverType *> m_observers;
};