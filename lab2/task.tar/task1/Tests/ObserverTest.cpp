#include <fstream>
#include "../Catch/Catch.hpp"
#include "../Observer/Observer.h"
#include "../Picture/Picture.h"

#include "../Shape/ShapeGeometry/ShapeGeometries/Circle/Circle.h"
#include "../Shape/ShapeGeometry/ShapeGeometries/Line/Line.h"
#include "../Shape/ShapeGeometry/ShapeGeometries/Rectangle/Rectangle.h"

class MockObserver : public IObserver<const shapes::Picture*> {
public:
    MockObserver() = default;

    void Update(const shapes::Picture* const& picture) override {
        m_countOfCalls++;
    }

    unsigned int m_countOfCalls = 0;
};

TEST_CASE("Наблюдатель Shape получает уведомление после изменения фигуры") {
    shapes::Line line(10, 10, 20, 20);
    shapes::IShape lineShape("1", gfx::Color("#FF00FF"), std::make_unique<shapes::Line>(line));
    MockObserver observer;
}


TEST_CASE("Изменение фигуры, принадлежащей Picture, приводит к уведомлению наблюдателя Picture") {
    std::ofstream svg("../output/output.svg");
    gfx::CanvasSvg canvas(svg);
    shapes::Picture picture(canvas);
    MockObserver observer;
    picture.RegisterObserver(observer);

    shapes::Circle circle(10, 100, 100);
    shapes::IShape circleShape("1", gfx::Color("#F0F0F0"), std::make_unique<shapes::Circle>(circle));
    shapes::IShape rectangle("2", gfx::Color("#F0F0F0"), std::make_unique<shapes::Rectangle>(100, 100, 100, 100));
    picture.AddShape(circleShape);

    REQUIRE(observer.m_countOfCalls == 1);
    circle.Move(100, 100);
    REQUIRE(observer.m_countOfCalls == 1);
    picture.AddShape(rectangle);
    REQUIRE(observer.m_countOfCalls == 2);
}

TEST_CASE("Добавление и удаление фигуры приводит к уведомлению наблюдателей Picture") {
    std::ofstream svg("../output/output.svg");
    gfx::CanvasSvg canvas(svg);
    shapes::Picture picture(canvas);
    MockObserver observer;
    picture.RegisterObserver(observer);

    shapes::Circle circle(10, 100, 100);
    shapes::IShape circleShape("1", gfx::Color("#F0F0F0"), std::make_unique<shapes::Circle>(circle));
    shapes::IShape rectangle("2", gfx::Color("#F0F0F0"), std::make_unique<shapes::Rectangle>(100, 100, 100, 100));

    REQUIRE(observer.m_countOfCalls == 0);
    picture.AddShape(circleShape);
    REQUIRE(observer.m_countOfCalls == 1);
    picture.DeleteShape("1");
    REQUIRE(observer.m_countOfCalls == 2);
}

TEST_CASE("Несколько наблюдателей одного субъекта получают уведомления") {
    std::ofstream svg("../output/output.svg");
    gfx::CanvasSvg canvas(svg);
    shapes::Picture picture(canvas);
    MockObserver observer1;
    MockObserver observer2;
    picture.RegisterObserver(observer1);
    picture.RegisterObserver(observer2);

    shapes::Circle circle(10, 100, 100);
    shapes::IShape circleShape("1", gfx::Color("#F0F0F0"), std::make_unique<shapes::Circle>(circle));
    shapes::IShape rectangle("2", gfx::Color("#F0F0F0"), std::make_unique<shapes::Rectangle>(100, 100, 100, 100));

    REQUIRE(observer1.m_countOfCalls == 0);
    REQUIRE(observer2.m_countOfCalls == 0);
    picture.AddShape(circleShape);
    REQUIRE(observer1.m_countOfCalls == 1);
    REQUIRE(observer2.m_countOfCalls == 1);
    picture.DeleteShape("1");
    REQUIRE(observer1.m_countOfCalls == 2);
    REQUIRE(observer2.m_countOfCalls == 2);
}

TEST_CASE("После отписки наблюдатель перестаёт получать уведомления") {
    std::ofstream svg("../output/output.svg");
    gfx::CanvasSvg canvas(svg);
    shapes::Picture picture(canvas);
    MockObserver observer;
    picture.RegisterObserver(observer);

    shapes::Circle circle(10, 100, 100);
    shapes::IShape circleShape("1", gfx::Color("#F0F0F0"), std::make_unique<shapes::Circle>(circle));

    REQUIRE(observer.m_countOfCalls == 0);
    picture.AddShape(circleShape);
    REQUIRE(observer.m_countOfCalls == 1);
    picture.RemoveObserver(observer);
    picture.DeleteShape("1");
    REQUIRE(observer.m_countOfCalls == 1);
}

TEST_CASE("Повторная регистрация наблюдателя не приводит к дублированию уведомлений") {
    std::ofstream svg("../output/output.svg");
    gfx::CanvasSvg canvas(svg);
    shapes::Picture picture(canvas);
    MockObserver observer;
    picture.RegisterObserver(observer);
    picture.RegisterObserver(observer);

    shapes::Circle circle(10, 100, 100);
    shapes::IShape circleShape("1", gfx::Color("#F0F0F0"), std::make_unique<shapes::Circle>(circle));

    REQUIRE(observer.m_countOfCalls == 0);
    picture.AddShape(circleShape);
    REQUIRE(observer.m_countOfCalls == 1);
    picture.RemoveObserver(observer);
    picture.DeleteShape("1");
    REQUIRE(observer.m_countOfCalls == 1);
}

TEST_CASE("Неуспешная операция, не изменившая состояние объекта, не приводит к уведомлению") {
    std::ofstream svg("../output/output.svg");
    gfx::CanvasSvg canvas(svg);
    shapes::Picture picture(canvas);
    MockObserver observer;
    picture.RegisterObserver(observer);
    picture.RegisterObserver(observer);

    shapes::Circle circle(10, 100, 100);
    shapes::IShape circleShape("1", gfx::Color("#F0F0F0"), std::make_unique<shapes::Circle>(circle));

    REQUIRE(observer.m_countOfCalls == 0);
    picture.AddShape(circleShape);
    REQUIRE(observer.m_countOfCalls == 1);
    circleShape.SetColor(gfx::Color("#F0F0F0"));
    REQUIRE(observer.m_countOfCalls == 1);
}

